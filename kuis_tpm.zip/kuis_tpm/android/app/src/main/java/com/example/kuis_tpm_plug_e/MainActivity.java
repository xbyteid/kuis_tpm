package com.example.kuis_tpm_plug_e;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
